/*
 *  ReportOnSet.cpp
 *  MonkeyWorksCore
 *
 *  Created by bkennedy on 8/26/08.
 *  Copyright 2008 MIT. All rights reserved.
 *
 */

#include "ReportOnSet.h"

// this is where the object is constructed

mw::ReportOnSet::ReportOnSet(const std::string &_tag, 
							 const boost::shared_ptr<mw::Variable> &variable, 
							 const std::string &_message) : mw::Component(_tag) {
	notif = shared_ptr<VariableNotification>(new ReportOnSetVariableNotification(_message));			
	variable->addNotification(notif);
}   

mw::ReportOnSet::~ReportOnSet() {
	notif->remove();
}
