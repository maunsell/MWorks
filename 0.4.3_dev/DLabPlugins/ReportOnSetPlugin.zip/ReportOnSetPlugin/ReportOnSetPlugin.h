/*
 *  ReportOnSetPlugins.h
 *  ReportOnSetPlugins
 *
 *  Created by bkennedy on 8/14/08.
 *  Copyright 2008 MIT. All rights reserved.
 *
 */

#ifndef ReportOnSetPLUGIN_H
#define ReportOnSetPLUGIN_H

#include "MonkeyWorksCore/Plugin.h"

// this is the class definition of the plugin.  The core knows to look for a function
// called "getPlugin()" that will return this particular plugin, and an object of type Plugin
// has a function called registerComponent. 

extern "C"{
	mw::Plugin *getPlugin();
}


namespace mw {
	class ReportOnSetPlugin : public Plugin {
		
		virtual void registerComponents(shared_ptr<mwComponentRegistry> registry);	
	};
}


#endif
