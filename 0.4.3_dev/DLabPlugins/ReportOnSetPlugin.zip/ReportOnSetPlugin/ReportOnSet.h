/*
 *  ReportOnSet.h
 *  MonkeyWorksCore
 *
 *  Created by bkennedy on 8/26/08.
 *  Copyright 2008 MIT. All rights reserved.
 *
 */

#ifndef ReportOnSet_H
#define ReportOnSet_H

#include "MonkeyWorksCore/Component.h"
#include "MonkeyWorksCore/GenericVariable.h"
#include "MonkeyWorksCore/VariableNotification.h"

// we need to create a notification to listen to the variable that's getting set
class ReportOnSetVariableNotification : public mw::VariableNotification {
protected:
	std::string message;
public:
	ReportOnSetVariableNotification(const std::string &_message) : mw::VariableNotification() {
		message=_message;
	}
	
	void notify(const mw::Data& data, mw::MonkeyWorksTime timeUS) {
		mw::mprintf("%s : %s", message.c_str(), data.toString().c_str());
	}
};

namespace mw {
	class ReportOnSet : public mw::Component {
	protected:
		shared_ptr<VariableNotification> notif;
	public:
		ReportOnSet(const std::string &_tag,
					const boost::shared_ptr<mw::Variable> &variable, 
					const std::string &message);
		virtual ~ReportOnSet();
	};
}
#endif 
