/*
 *  ReportOnSetFactory.cpp
 *  MonkeyWorksCore
 *
 *  Created by bkennedy on 8/26/08.
 *  Copyright 2008 MIT. All rights reserved.
 *
 */

#include "MonkeyWorksCore/GenericVariable.h"
#include "MonkeyWorksCore/ComponentRegistry_new.h"
#include "ReportOnSetFactory.h"
#include "ReportOnSet.h"

boost::shared_ptr<mw::Component> mw::ReportOnSetPluginFactory::createObject(std::map<std::string, std::string> parameters,
																	  mw::mwComponentRegistry *reg) {
	REQUIRE_ATTRIBUTES(parameters, 
					   "tag",
					   "variable",
					   "some_integer_greater_than_5",
					   "message");
	
	std::string tagname(parameters.find("tag")->second);
	std::string message(parameters.find("message")->second);
	
	boost::shared_ptr<mw::Variable> variable = reg->getVariable(parameters.find("variable")->second);
	
	int an_integer_greater_than_5 = reg->getNumber(parameters.find("some_integer_greater_than_5")->second);
	if(an_integer_greater_than_5 <= 5) {
		throw mw::SimpleException("ReportOnSet: an_integer_greater_than_5 <= 5");
	}
	
	boost::shared_ptr <mw::ReportOnSet> new_shell_ = boost::shared_ptr<mw::ReportOnSet>(new mw::ReportOnSet(tagname, 
																											variable, 
																											message));
	
	return new_shell_;
}

