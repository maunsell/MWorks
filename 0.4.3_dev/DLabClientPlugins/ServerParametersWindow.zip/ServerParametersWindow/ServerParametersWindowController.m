#import "MonkeyWorksCore/StandardVariables.h"
#import "MonkeyWorksCocoa/MWCocoaEvent.h"
#import "ServerParametersWindowController.h"

#define WINDOW_CALLBACK_KEY @"ServerParametersWindowController callback key"

// these are the methods that are used to 
@interface ServerParametersWindowController(PrivateMethods)
- (void)newCodecReceived:(MWCocoaEvent *)codec;
- (void)serviceDisplayEvent:(MWCocoaEvent *)display_event;
@end

@implementation ServerParametersWindowController

- (void)awakeFromNib {
	// put initialization code here
}

- (void)dealloc {
	// put tear down code here
	//
	[super dealloc];
}

// this creates the acessor methods for "delegate"  It automatically creates
// [self delegate] and [self setDelegate:new_delegate]
@synthesize delegate=delegate;
@synthesize refreshRate=refresh_rate;
@synthesize width=width;
@synthesize height=height;
@synthesize distance=distance;
@synthesize showMirrorWindow=show_mirror_window;
@synthesize mirrorWindowHeight=mirror_window_height;
@synthesize displayNumber=display_number;


// we're going to override setDelegate so we can have checks to make sure that all of 
// the required methods exist.  The delegate for client windows is MWClientInstance in
// the client application.
- (void)setDelegate:(id)new_delegate {
	
	// check to make sure the delegate has all of the required methods
	if(![new_delegate respondsToSelector:@selector(registerEventCallbackWithReceiver:
												   andSelector:
												   andKey:)] ||
	   ![new_delegate respondsToSelector:@selector(registerEventCallbackWithReceiver:
												   andSelector:
												   andKey:
												   forVariableCode:)] ||
	   ![new_delegate respondsToSelector:@selector(codeForTag:)] ||
	   ![new_delegate respondsToSelector:@selector(unregisterCallbacksWithKey:)] ||
	   ![new_delegate respondsToSelector:@selector(updateVariableWithCode: withData:)]) {
		[NSException raise:NSInternalInconsistencyException
					format:@"Delegate doesn't respond to required methods for ServerParametersWindowController"];		
	}
	

	delegate = new_delegate;
	// at first, just register a listener for the codec.  This call sets up a callback.  
	// newCodecReceived: will get called at every event received by the client.  We use the
	// key TEMPLATE_WINDOW_CALLBACK_KEY so we can unregister it later.
	[delegate registerEventCallbackWithReceiver:self 
									andSelector:@selector(newCodecReceived:)
										 andKey:WINDOW_CALLBACK_KEY
								forVariableCode:[NSNumber numberWithInt:RESERVED_CODEC_CODE]];
	
}

- (IBAction)updateDisplayParameters:(id)sender {
	mw::Data new_main_screen_info(mw::M_DICTIONARY, 7);
	
	new_main_screen_info.addElement(M_DISPLAY_WIDTH_KEY, self.width);                                                     
	new_main_screen_info.addElement(M_DISPLAY_HEIGHT_KEY, self.height);                                                   
	new_main_screen_info.addElement(M_DISPLAY_DISTANCE_KEY, self.distance);                                               
	new_main_screen_info.addElement(M_DISPLAY_TO_USE_KEY, (long)self.displayNumber);                                            
	new_main_screen_info.addElement(M_ALWAYS_DISPLAY_MIRROR_WINDOW_KEY, self.showMirrorWindow);                           
	new_main_screen_info.addElement(M_MIRROR_WINDOW_BASE_HEIGHT_KEY, self.mirrorWindowHeight);                            
	new_main_screen_info.addElement(M_REFRESH_RATE_KEY, self.refreshRate);  
	
	NSNumber *main_display_info_codec_code = [delegate codeForTag:[NSString stringWithCString:MAIN_SCREEN_INFO_TAGNAME 
																					 encoding:NSASCIIStringEncoding]];
	
	[delegate updateVariableWithCode:[main_display_info_codec_code intValue] withData:&new_main_screen_info];
}


/*******************************************************************
 *                           Private Methods
 *******************************************************************/

// if a new codec is received, it's a good idea to reregister the callbacks in case a codec code changed.
// initially all events are registered, but by registering them individually, we can reduce the load on the
// by ignoring events that aren't used.
- (void)newCodecReceived:(MWCocoaEvent *)event {
	// first unregister all of the existing callbacks
	[delegate unregisterCallbacksWithKey:WINDOW_CALLBACK_KEY];

	// register the codec callback
	[delegate registerEventCallbackWithReceiver:self 
									andSelector:@selector(newCodecReceived:)
										 andKey:WINDOW_CALLBACK_KEY
								forVariableCode:[NSNumber numberWithInt:RESERVED_CODEC_CODE]];

	NSNumber *main_display_info_codec_code = [delegate codeForTag:[NSString stringWithCString:MAIN_SCREEN_INFO_TAGNAME 
																					 encoding:NSASCIIStringEncoding]];
	[delegate registerEventCallbackWithReceiver:self 
									andSelector:@selector(serviceDisplayEvent:)
										 andKey:WINDOW_CALLBACK_KEY
								forVariableCode:main_display_info_codec_code];
}

- (void)serviceDisplayEvent:(MWCocoaEvent *)display_event {
	mw::Data *main_screen_info = [display_event data];
	
	mw::Data main_width = main_screen_info->getElement(M_DISPLAY_WIDTH_KEY);
	mw::Data main_height = main_screen_info->getElement(M_DISPLAY_HEIGHT_KEY);
	mw::Data main_distance = main_screen_info->getElement(M_DISPLAY_DISTANCE_KEY);
	mw::Data main_display_number = main_screen_info->getElement(M_DISPLAY_TO_USE_KEY);
	mw::Data display_mirror = main_screen_info->getElement(M_ALWAYS_DISPLAY_MIRROR_WINDOW_KEY);
	mw::Data mirror_height = main_screen_info->getElement(M_MIRROR_WINDOW_BASE_HEIGHT_KEY);
	mw::Data main_display_refresh_rate = main_screen_info->getElement(M_REFRESH_RATE_KEY);
	
	self.width = main_width.getFloat();
	self.height = main_height.getFloat();
	self.distance = main_distance.getFloat();
	self.displayNumber = main_display_number.getInteger();
	self.showMirrorWindow = display_mirror.getBool();
	self.refreshRate = main_display_refresh_rate.getInteger();
	self.mirrorWindowHeight = mirror_height.getFloat();
}


@end
