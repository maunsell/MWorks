/* ServerParametersWindowController */

// This is the minimum that is needed for a window.  It's likely that more will be
// if you want the window to do anything.

@interface ServerParametersWindowController : NSWindowController {			
	IBOutlet id delegate;
	
	float refresh_rate;
	float width;
	float height;
	float distance;
	unsigned int display_number;
	bool show_mirror_window;
	float mirror_window_height;
}


// Accessors
@property (readwrite, assign) id delegate;
@property (readwrite, assign) float refreshRate;
@property (readwrite, assign) float width;
@property (readwrite, assign) float height;
@property (readwrite, assign) float distance;
@property (readwrite, assign) unsigned int displayNumber;
@property (readwrite, assign) bool showMirrorWindow;
@property (readwrite, assign) float mirrorWindowHeight;

- (IBAction)updateDisplayParameters:(id)sender;

@end
